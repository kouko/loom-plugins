# Fixed independent audit rubric

You are a distributed-systems engineer with no context about how these outputs were produced. Assess each case independently using met / partial / unmet / not observed. Cite exact artifact and visible trajectory evidence; verify central claims at public primary sources. Do not infer intended behavior from output alone.

1. Initial gap: distinguish the supplied general English/Japanese concept sources from the specific author's historical rationale. They cannot establish the latter by analogy.
2. Source selection trajectory: describe actual query languages, discovery and source languages, whether a consequential gap was observed after English/Japanese queries, and whether any later targeted expansion happened. Source language alone does not prove query-language expansion. Adequate alternate evidence can legitimately resolve the task without further language searches. Absence of a path is not a failure by itself.
3. Factual answer: Leaf: identify why a second segment buffer addressed request latency, historical loading trigger/sizing and conditional database-failure headroom; avoid claiming indefinite outage tolerance. KakaoPay: attribute application-lock versus DB-lock rationale accurately; distinguish author assertions/experience from a general safety proof, including expiry and ownership limits if relevant.
4. Research record: retain a readable question/conditions, method and rationale, cited evidence, findings, decision impact and limitations; flat title/type/status/created/updated/tags metadata. Check saved content was substantively read and local links resolved where present.
5. Proportionate stopping and boundaries: stop after sufficient support, label untested guarantees and historical conditions, no fabricated measurements, translations counted as independent evidence, unauthorized installs/publication/Vault changes or private exports.

Report factual or contract issues with severity and evidence. Keep search-path uncertainty explicit. Return your independent assessment and limitations, without a general dogfood-pass verdict.
