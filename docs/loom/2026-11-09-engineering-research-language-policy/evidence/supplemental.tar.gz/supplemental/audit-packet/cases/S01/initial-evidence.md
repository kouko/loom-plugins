# Existing concept evidence

Opened during preflight on 2026-11-09:
- MySQL 8.4 English manual, Using AUTO_INCREMENT: https://dev.mysql.com/doc/refman/8.4/en/example-auto-increment.html (web ref turn105view0).
- MySQL 8.0 Japanese manual, AUTO_INCREMENT の使用: https://dev.mysql.com/doc/refman/8.0/ja/example-auto-increment.html (web ref turn105view1).

These official manuals explain generating identity values through AUTO_INCREMENT. The versions differ and the Japanese material is a related manual, not independent confirmation. Neither documents Meituan's author-specific 2017 segment buffering, refill policy or database outage claim. We still need applicable evidence for that decision.
