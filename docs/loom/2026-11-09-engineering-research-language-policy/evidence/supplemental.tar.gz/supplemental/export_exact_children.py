"""One-use visible-action export; exact children only, no reasoning channels."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
PARENT = '01a1bc81-a42b-7961-9410-e239ac1651bc'
PREFIX = '/root/language_supplement_worker/'
NAMES = {'supp_exec_s01', 'supp_exec_s02', 'supp_audit_01', 'supp_audit_02'}
summary = []
for source in Path('/Users/kouko/.codex/sessions/2026/11/09').glob('*.jsonl'):
    with source.open() as stream:
        first = json.loads(next(stream))['payload']
        origin = first.get('source', {})
        spawn = origin.get('subagent', {}).get('thread_spawn', {}) if isinstance(origin, dict) else {}
        path = spawn.get('agent_path', '')
        name = path.removeprefix(PREFIX)
        if spawn.get('parent_thread_id') != PARENT or path != PREFIX + name or name not in NAMES:
            continue
        calls, kept, blind, models, efforts = {}, [], [], set(), set()
        for raw in stream:
            item = json.loads(raw)
            payload = item.get('payload', {})
            kind = payload.get('type')
            if item.get('type') == 'turn_context':
                models.add(payload.get('model'))
                efforts.add(payload.get('effort', payload.get('reasoning_effort')))
            if item.get('type') != 'response_item':
                continue
            if kind in ('custom_tool_call', 'function_call'):
                clean = {k: payload[k] for k in ('type', 'name', 'call_id', 'input', 'arguments') if k in payload}
                calls[clean['call_id']] = str(clean.get('input', clean.get('arguments', '')))
            elif kind in ('custom_tool_call_output', 'function_call_output'):
                clean = {k: payload[k] for k in ('type', 'call_id', 'output') if k in payload}
                body = json.dumps(clean.get('output'), ensure_ascii=False)
                code = calls.get(clean['call_id'], '')
                if 'web__run' in code:
                    output = clean.get('output', [])
                    parts = output if isinstance(output, list) else [{'text': str(output)}]
                    returned = '\n'.join(x.get('text', '') for x in parts if isinstance(x, dict))
                    clean['output'] = {
                        'source_bodies_omitted': True,
                        'original_output_sha256': hashlib.sha256(body.encode()).hexdigest(),
                        'original_output_bytes': len(body.encode()),
                        'urls': sorted(set(re.findall(r'https?://[^\s<>"\\]+', body))),
                        'reference_ids': sorted(set(re.findall(r'turn\d+(?:search|view|fetch|academia)\d+', body))),
                        'observed_error': bool(re.search(r'Internal Error|403 Forbidden|404 Not Found|not accessible via this tool', body)),
                        'error_statuses': [x.strip()[:300] for x in returned.splitlines() if re.search(r'Internal Error|403 Forbidden|404 Not Found|not accessible via this tool|Failed to fetch', x)],
                        'no_match_statuses': re.findall(r'No matching text found for[^\n\\]{0,200}', body),
                    }
            elif kind == 'message' and payload.get('role') == 'user':
                clean = {k: payload[k] for k in ('type', 'role', 'content') if k in payload}
            elif kind == 'message' and payload.get('role') == 'assistant' and (payload.get('channel') == 'final' or payload.get('phase') == 'final_answer'):
                clean = {k: payload[k] for k in ('type', 'role', 'channel', 'phase', 'content') if k in payload}
            else:
                continue
            record = {'timestamp': item.get('timestamp'), 'payload': clean}
            kept.append(record)
            masked = json.loads(json.dumps(record))
            if kind in ('custom_tool_call_output', 'function_call_output') and '/candidate/engineering-research' in calls.get(clean['call_id'], ''):
                body = json.dumps(clean.get('output'), ensure_ascii=False)
                masked['payload']['output'] = {'skill_read_result_withheld': True, 'original_output_sha256': hashlib.sha256(body.encode()).hexdigest()}
            blind.append(masked)
    target = ROOT / 'traces' / name
    target.mkdir(parents=True, exist_ok=True)
    for filename, rows in [('trajectory.jsonl', kept), ('audit-trajectory.jsonl', blind)]:
        (target / filename).write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in rows))
    meta = {'agent_path': path, 'thread_id': first['id'], 'parent_thread_id': PARENT, 'source_file': source.name,
            'host_reported_models': sorted(x for x in models if x), 'host_reported_efforts': sorted(x for x in efforts if x),
            'retained_records': len(kept), 'retained_hidden_reasoning': 0, 'external_bodies_republished': False}
    (target / 'provenance.json').write_text(json.dumps(meta, indent=2) + '\n')
    for row in kept:
        p = row['payload']
        if p.get('role') == 'assistant':
            answer = ''.join(x.get('text', '') for x in p.get('content', []) if isinstance(x, dict))
            (target / 'answer.txt').write_text(answer + '\n')
    summary.append(meta)
(ROOT / 'trace-export-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'exported_agents': len(summary), 'retained_hidden_reasoning': 0}))
