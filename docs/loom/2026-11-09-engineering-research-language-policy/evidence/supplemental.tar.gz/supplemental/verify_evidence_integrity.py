"""One-use standard-library verification, no runtime or maintained test harness."""
from pathlib import Path
import hashlib
import json
import re
import posixpath
import tarfile

BASE = Path('/private/tmp/loom-engineering-research-language-policy-delivery/docs/loom/2026-11-09-engineering-research-language-policy/evidence')
digest = lambda b: hashlib.sha256(b).hexdigest()
result = {'command': 'python3 /private/tmp/engineering-research-language-supplement-20261109/verify_evidence_integrity.py', 'archives': {}, 'freeze_mismatches': [], 'missing_report_links': [], 'hidden_reasoning_records': 0}
contents = {}
for name in ('first-trial', 'supplemental'):
    inventory = json.loads((BASE / (name + '.inventory.json')).read_text())
    archive_path = BASE / inventory['archive']
    assert digest(archive_path.read_bytes()) == inventory['sha256'], name + ' archive SHA'
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in members)
        data = {x.name: archive.extractfile(x).read() for x in members}
    expected = {x['path']: x for x in inventory['members']}
    assert set(data) == set(expected), name + ' member inventory'
    for path, body in data.items():
        assert len(body) == expected[path]['size'] and digest(body) == expected[path]['sha256'], path
        if path.endswith('trajectory.jsonl'):
            for line in body.splitlines():
                p = json.loads(line)['payload']
                assert p.get('type') in {'custom_tool_call', 'function_call', 'custom_tool_call_output', 'function_call_output', 'message', 'agent_message'}, path
                assert p.get('channel') not in {'analysis', 'summary'}, path
    contents[name] = data
    result['archives'][name] = {'sha256': inventory['sha256'], 'members': len(data), 'inventory_verified': True}
for name, files in contents.items():
    freeze = json.loads(files[name + '/freeze.json'])
    for rel, wanted in freeze['hashes'].items():
        if digest(files[name + '/' + rel]) != wanted:
            result['freeze_mismatches'].append(name + '/' + rel)
    packet = json.loads(files[name + '/audit-packet-freeze.json'])
    for rel, wanted in packet['files'].items():
        if digest(files[name + '/audit-packet/' + rel]) != wanted:
            result['freeze_mismatches'].append(name + '/audit-packet/' + rel)
candidate = json.loads(contents['supplemental']['supplemental/freeze.json'])['candidate_hashes']
for rel, wanted in candidate.items():
    assert digest(contents['first-trial']['first-trial/candidate/engineering-research/' + rel]) == wanted, rel
original_report = 'first-trial/workspace/docs/skill-dogfood/2026-11-09-engineering-research-language-policy/report.md'
original_links = re.findall(r'\]\(([^)]+)\)', contents['first-trial'][original_report].decode())
checked = 0
for link in original_links:
    if '://' in link or link.startswith('#'):
        continue
    target = posixpath.normpath(posixpath.join(posixpath.dirname(original_report), link.split('#', 1)[0]))
    assert target in contents['first-trial'], ('first-trial report local link', link, target)
    checked += 1
assert checked == 48, checked
result['first_trial_report_local_links_checked'] = checked
for name, count in [('first-trial', 9), ('supplemental', 4)]:
    summaries = json.loads(contents[name][name + '/trace-export-summary.json'])
    assert len(summaries) == count
    for p in summaries:
        assert p['host_reported_models'] == ['gpt-6.1-sol'] and p['host_reported_efforts'] == ['medium'], p
        assert p['retained_hidden_reasoning'] == 0, p
    result['archives'][name]['native_assignments_verified'] = count
report = BASE / 'observations.md'
links = re.findall(r'\]\(([^)]+)\)', report.read_text())
for link in links:
    if '://' in link or link.startswith('#'):
        continue
    target = link.split('#', 1)[0]
    if target and not (report.parent / target).is_file():
        result['missing_report_links'].append(link)
result['report_local_links_checked'] = sum('://' not in x and not x.startswith('#') for x in links)
assert not result['freeze_mismatches'] and not result['missing_report_links'], result
result['status'] = 'verified structural integrity only; no semantic or workflow verdict'
print(json.dumps(result, indent=2))
