# Supplemental workflow observations

Prospective scope: two public engineering attribution questions, one about Meituan Leaf's 2017 segment design and one about KakaoPay's 2024 quiz reward concurrency choice. Predictable risk: an executor substitutes generic mechanism knowledge for the author's actual reason, or presents historical production experience as a universal guarantee.

This is only a supplemental Probe B. No activation rerun, control comparison, general quality improvement or broad dogfood verdict is claimed. Retain the previous six-case experiment unchanged, including its blind audits and disputed JDBC qualification.

Before actors: freeze this protocol, tasks, initial evidence, rubric, oracle and exact existing candidate hashes. Executors receive only their task, initial evidence, raw candidate skill and private scratch workspace. They receive no oracle, language target, prior output or auditor feedback. Do not simulate search failure, suppress adequate evidence or force a query language. Discovery of original sources through English/Japanese queries counts as that observed path, not delayed language expansion.

Use native fresh gpt-6.1-sol, medium executors sequentially, then two independent blind auditors. Auditors receive tasks, initial evidence, fixed rubric, outputs and visible action traces, with skill read results masked; no skill text, oracle or peer assessment. Audits are advisory; human calibration remains necessary.

Export only exact children: visible user task, public tool inputs, public source identities/ref IDs, error/no-match observations, returned-output hashes, and final answers. Exclude reasoning, parent history and unrelated sessions. Omit full external page/search bodies. Archive deterministic data with SHA256/member inventory. One-use helper scripts are historical data only.
