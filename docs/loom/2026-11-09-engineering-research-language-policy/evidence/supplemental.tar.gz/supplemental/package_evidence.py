"""One-use deterministic archival command; standard library only."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

BASE = Path('/private/tmp/loom-engineering-research-language-policy-delivery/docs/loom/2026-11-09-engineering-research-language-policy/evidence')
ROOTS = {
    'first-trial': Path('/private/tmp/engineering-research-language-dogfood-20261109'),
    'supplemental': Path('/private/tmp/engineering-research-language-supplement-20261109'),
}
BASE.mkdir(parents=True, exist_ok=True)
for name, root in ROOTS.items():
    members = []
    target = BASE / (name + '.tar.gz')
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
                for p in sorted(root.rglob('*')):
                    if not p.is_file():
                        continue
                    assert not p.is_symlink(), p
                    content = p.read_bytes()
                    rel = p.relative_to(root).as_posix()
                    info = tarfile.TarInfo(name + '/' + rel)
                    info.size, info.mode, info.mtime = len(content), 0o644, 0
                    archive.addfile(info, io.BytesIO(content))
                    members.append({'path': info.name, 'size': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
    inventory = {'archive': target.name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                 'format': 'ustar+gzip; sorted regular files; gzip mtime=0; normalized mode/uid/gid/mtime', 'members': members}
    (BASE / (name + '.inventory.json')).write_text(json.dumps(inventory, indent=2) + '\n')
    print(name, len(members), inventory['sha256'])
