# Preflight oracle — withheld from executors and auditors

Public primary source checks, 2026-11-09:
- https://tech.meituan.com/2017/04/21/mt-leaf.html (turn104view0/turn104search1): second buffer addresses request blocking on database refill and tail latency. Historical refill at 10% issued; suggested segment sizing 600 times peak QPS; stated 10–20 minute headroom is conditional. This is not indefinite outage tolerance.
- https://tech.kakaopay.com/post/troubleshooting-logs-as-a-junior-developer/ (turn104view2/turn104search0): author prefers application maintenance and Controller-level early rejection to Repository/Infra-level DB lock exception/resource use. Example uses SETNX with 3-second expiry and direct key deletion; this does not itself prove safe ownership on expiry or exactly-once reward processing.

Preflight English/Japanese exploratory queries (real, not failed by fiat): Meituan Leaf double buffer segment database outage 2017 rationale; 美団 Leaf ダブルバッファ 採番 2017 設計; KakaoPay junior developer quiz reward Redis Lettuce distributed lock transaction separation 2024; カカオペイ クイズ Redis 分散ロック トランザクション 2024. Batch returned the first-party original-language pages. Thus discovery may succeed immediately; this experiment cannot promise delayed expansion. Initial evidence deliberately contains genuine general concept documentation, not an alleged exhaustive EN/JA search result.
