# Prospective language-policy dogfood, trial 1

Target: frozen raw candidate, source commit 11b962b7f2c83f397c52d0753fd890ffec06e74b, plugin 3.60.0. Only source-policy gains the proposed language paragraph. Neither source checkout nor installed skills are modified. Baseline is a byte reference, not an executed control.

Six fresh, explicit-invocation native Codex executors run one genuine public/local-source question each. They receive only candidate paths, their task and their own workspace. Requested model is gpt-6.1-sol, medium; this is a requested pin, not provider-served attestation. No Claude CLI, external model CLI/API, private fixtures, real Vault, installs, deletion, publishing or repository mutation. Public web lookup is allowed except C03's explicit offline scope. Context isolation is fresh fork without parent history; native host defaults and tool infrastructure are not a full filesystem sandbox or empty installed catalog.

Probe A is not rerun: description is byte-identical. No current activation result or full-skill dogfood pass is claimed. Probe B is six one-shot workflow cases, with no automatic repair/retry loop. Probe C is one fresh cold reader. Two independent blind auditors receive a neutral rubric, actual outputs and filtered tool trajectories, not the candidate body, author's predicted defects, other judgments or repair history. Exact models/effort remain recorded; judgments are advisory met/partial/not-met/not-observed, never statistical quality estimates.

Highest-risk axes and prospective failure predictions:
- C01 exploratory: the executor may use only English, combine both languages into one query, or gratuitously search all four.
- C02 known applicable official URL: it may manufacture bilingual searches despite enough direct official evidence.
- C03 sufficient genuine local manifest: it may browse or infer an installed/running version from package metadata.
- C04 upstream Chinese primary community: it may delay relevant original-language sources until after an English/Japanese failure, or expand Korean without a reason.
- C05 upstream Korean material: it may miss original-language clues, treat translations as independent corroboration, or claim the guidelines prove universal outcomes.
- C06 relevant Russian primary material: it may treat the four named languages as an exclusive allowlist.

These axes test conformance, not EN/JA superiority. C04/C05 may correctly resolve by opening primary sources without submitting an additional translated search query; distinguish source use from query-language expansion. Do not force extra searches to obtain a favorable test. Results-driven expansion after an actual insufficient EN/JA result is measured only if it genuinely occurs; otherwise remains untested. No synthetic search responses or invented source text.

Ground truth is actual public sources and the supplied real plugin manifest. Preserve exact identifiers/version conditions. Relevant GitHub implementation claims still require connected source inspection; documentation-only findings must be labeled. No per-case source/tool quota. Stop once adequate evidence or a genuine limitation is established.

Main extracts ONLY these new executor/cold-reader/auditor session tool calls/results and final messages by exact agent_path from local rollout metadata; no hidden reasoning, credentials or unrelated sessions are copied. Actor-authored action logs are supplementary, not independent proof. If host-native traces are unavailable, mark the boundary instead of substituting self-report as observed behavior. Freeze artifacts before blind audits, retain original failures/disagreements, and never silently rewrite the candidate after execution.

Output: workspace/docs/skill-dogfood/2026-11-09-engineering-research-language-policy/report.md, with findings localized to the raw candidate, evidence links, exact prompts, actual query/source chronology and independently returned judgments. No auto-fix or merge-ready verdict.
