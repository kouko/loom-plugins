# Dogfood report — engineering-research language-policy trial 1

Both independent auditors rated language/query choice met in all six observed cases. The new paragraph was executable in those branches, including stopping without unnecessary searches. This is not an overall dogfood-pass, a reliability estimate or evidence of improvement over the existing skill. Korean query expansion and delayed Chinese/Korean expansion after insufficient English/Japanese results were not exercised. One domain-quality judgment remains disputed.

## Metadata

| Field | Value |
|---|---|
| Date | 2026-11-09, Asia/Taipei |
| Baseline | loom-code 3.60.0 at 11b962b7f2c83f397c52d0753fd890ffec06e74b; reference only, not an executed control |
| Raw skill | [candidate SKILL.md](../../../../candidate/engineering-research/SKILL.md) and its directly linked bundle |
| Change | Only references/source-policy.md; eight added physical lines, zero deletions; [exact diff](../../../../candidate.diff) |
| Source inventory | Seven runtime Markdown files plus human README; description unchanged |
| Assignments | Six fresh native Codex executors, one cold reader, two independent blind auditors; one execution per assignment |
| Model | Requested and host-reported gpt-6.1-sol / medium; not provider-served attestation |
| Activation | Not rerun; no current automatic-routing or installed-host result |
| Protocol | [Prospective protocol](../../../../protocol.md), [input hashes](../../../../freeze.json), [neutral rubric](../../../../rubric.md) |
| Data and actions | Public primary sources and a genuine local manifest; no installs, real Vault, Git mutation, deployment, external model CLI/API or publication |

Fresh actors receive no parent conversation. That is not proof of an empty installed catalog, removal of all host defaults or hard filesystem confinement. No baseline condition was executed, so these observations cannot establish that the added paragraph caused the choices or improved quality, cost or speed. No automatic repair/resampling loop was run.

## Observed results

Scores are advisory judgments of observed dimensions, not population rates or exhaustive certification.

| Case | Actual behavior | Language A01 / A02 | Factual evidence A01 / A02 | Record verification A01 / A02 |
|---|---|---|---|---|
| C01 — small-PR tradeoffs | Separate English/Japanese queries batched in the initial search | met / met | met / met | met / met |
| C02 — Git documentation | Direct official-document reads; zero discovery-search calls | met / met | met / met | met / met |
| C03 — local package condition | Genuine local manifest; zero web calls | met / met | met / met | met / met |
| C04 — Rime persistence | English/Japanese/Chinese queries in the first batch; original Wiki and version-specific implementation | met / met | met / met | met / met |
| C05 — Toss quality guidance | Direct Korean original and linked cases; zero discovery-search calls | met / met | met / met | met / met |
| C06 — YDB Online Read-Only | Direct Russian official source and SDK document; zero discovery-search calls | met / met | partial / met | met / met |

Actual C01 initial queries were `small pull requests tradeoffs large pull requests empirical study code review size` and `小さい プルリクエスト 分割 デメリット コードレビュー 経験`, in one search array.

Actual C04 first-batch queries were `site:github.com/rime save_options key_binder toggle limitations`, `site:github.com/rime save_options キー 切り替え`, and `site:github.com/rime save_options 選項 保存 切換`. Relevant Chinese querying did not wait for an English/Japanese-only failure. Korean was not automatically added with Chinese.

C05's early Korean reading is not Korean query expansion. C06's Russian reading is not discovery without a supplied source. C03's early-original dimension is not-observed in A01 versus met in A02, reflecting external versus local primary-evidence classification, not an offline/language failure.

Both auditors observed substantive saved-content readback across all six records. C03 additionally resolved and parsed the linked manifest. Correct formatting and readback do not guarantee an exhaustive technical answer.

## Severity summary

These are advisory findings, not production gate verdicts. No new language-policy defect was confirmed. Reader-only concerns are unchanged baseline text; the host incident recovered.

| Severity | Domain finding | Inherited reader finding | Environment incident |
|---|---:|---:|---:|
| Critical | 0 | 0 | 0 |
| High | 0 | 0 | 0 |
| Medium | 1, disputed coverage judgment | 0 | 0 |
| Low | 0 | 1, three related context questions | 1, recovered |

## Findings

### F01 — SDK-specific condition absent from the YDB answer

- **Severity/category/pass:** Medium / Output-quality / blind A01. Not a language-policy failure.
- **Probe prompt:** C06 requests Online Read-Only limitations and alternatives from the supplied Russian official source, with untested behavior identified and no database execution. [Exact input](../../../../runs/C06/prompt.txt).
- **Expected:** Retain material conditions with their applicable SDK scope; do not project one mode's restrictions onto another.
- **Actual:** A01 rates factual evidence partial for an omitted Online RO JDBC interactive-transaction condition. A02 rates the core document conclusions met, without specifically refuting that JDBC finding. The difference remains unresolved, not averaged away.
- **Transcript/artifact evidence:** A01 F01 cites the SDK-page find call and the note's warning, “不能把 Stale 的互動交易限制無條件移植成 Online 的限制”. [A01](../../../../audits/A01.json), [A02](../../../../audits/A02.json), [actual case record](../../../../runs/C06/workspace/docs/loom/research/2026-11-09-ydb-online-read-only.md).
- **Root cause:** Not established. A current-page condition is missing, but this does not prove the executor received and ignored its exact passage. The original find return reports no match for its Russian interactive-transaction term; see the evaluator boundary below.
- **Why static review missed it:** Original-language visits, valid record fields and full saved-body readback can coexist with incomplete SDK-condition coverage.
- **Location:** C06 Findings/limitations; existing critical-claim applicability guidance, not the new Search languages paragraph.
- **Suggested edit class:** Verify and add only the applicable JDBC condition to this case if repaired; retain unknown other-SDK/runtime behavior. No extra language or new mandatory skill rule is justified. No repair applied.
- **Repro:** Inspect the unchanged artifacts/trace and the Online Read-Only/JDBC section of the [official SDK page](https://ydb.tech/docs/ru/recipes/ydb-sdk/tx-control), preserving document/version and returned-content limits.

### F02 — Unspecified caller context raises cold-reader questions

- **Severity/category/pass:** Low / Cold-start / blind cold reader. Three related advisory context questions, not measured runtime or trigger failures.
- **Probe prompt:** Is it self-contained without its author? Which requests are uncertain? Are procedures executable? Which boundaries are undefined?
- **Expected/actual:** The reader can act in a known project and finds the language procedure actionable, but asks about standalone save-root, ordinary review versus consequential research, and an unspecified finishing command.
- **Transcript evidence:** “whether an ordinary review with potential unknowns invokes the entire research-record obligation”; the reader also identifies the “finishing command's printed cleanup destination” assumption. [Verbatim cold read](../../../../cold-reader.txt).
- **Root cause/location:** Caller context assumed in SKILL.md Retained research records/Return to the owning task, evaluation-selection's review examples and preservation's cleanup integration. These passages were not changed by the candidate.
- **Why static review missed it:** An author supplies project/station context implicitly; a standalone first-time reader may not have it.
- **Suggested edit classes:** Clarify owning-root resolution or unsaved fallback; give a bounded ordinary-review/evidence-gap example if needed; obtain cleanup evidence from the owning task or defer. Do not add arbitrary thresholds or new cleanup authority. These are suggestions, not automatic repairs.
- **Repro/limit:** Fresh reading outside established caller context. All six executors instead had explicit workspaces; no wrong destination, actual trigger miss or preservation failure was observed.

### F03 — Harmless documentary prose triggers a recovered guard rejection

- **Severity/category/pass:** Low / Environment-tooling / actual C02, corroborated by both auditors; not a demonstrated candidate defect.
- **Probe prompt:** C02's document-only Git option question.
- **Expected/actual:** A Python write containing branch-option prose was rejected by dcg; the actor used the file-patch tool and completed substantive record readback.
- **Transcript evidence:** “Command blocked by PreToolUse hook: BLOCKED by dcg”; the input is a document write, not executable Git deletion. [Audited C02 trace](../../../../audit-packet/traces/C02/trajectory.jsonl), [A02 finding](../../../../audits/A02.json).
- **Root cause/location:** Host command interpretation of embedded text, outside the language paragraph.
- **Why static review missed it:** The content is harmless; transport interpretation caused the interruption.
- **Suggested edit class:** Prefer the available file-patch transport. Guard changes are separate work; no approval bypass or policy edit follows.
- **Repro/limit:** Retain the rejected input/output; do not execute deletion to reproduce the label. No Git state changed.

## Supported branches and limits

Supported in these cases: separate batched English/Japanese exploratory queries, immediate relevant Chinese queries, no forced searches when evidence is sufficient, early Korean original reading, relevant Russian source acceptance, and actual saved-record readback. The cold reader found the added paragraph actionable.

Not established: Korean discovery-query expansion; delayed Chinese/Korean expansion after genuinely insufficient English/Japanese results; choosing Korean/Russian originals without a supplied entry; resistance to mistakenly double-counting translations; current activation, installed-host or other-host behavior; repeated-run reliability; causal quality/cost/latency improvement. Baseline was not run and no unconditional dogfood-pass is assigned.

Do not remove the sufficiency exceptions merely to force a query in a completed question. A later targeted coverage case should have a genuinely unresolved gap. This trial supports executability, not general superiority or complete coverage.

## Source-return and evaluator boundaries

Only these nine new exact child agent paths were exported. Hidden reasoning, parent history, credentials and unrelated sessions were not copied. Actor actions.json files are supplementary; actual native calls establish query/source chronology.

The frozen auditor packet masks skill text and omits external page bodies rather than republishing them. Actual calls, URLs/IDs, hashes and coarse access observations remain. Both auditors independently reopened consequential primary sources. Later live content cannot establish the exact original response or its complete inspection.

After packet freeze, the main agent separately extracted tool-generated no-match statuses from the original C04/C06 returns. C06's original SDK find says no matching text for the Russian interactive-transaction term. The first export had not retained this status separately. The [post-freeze supplement](../../../../source-return-supplement.json) was not given to the independent initial judgments; the [audited packet](../../../../audit-packet-freeze.json) is unchanged. This does not prove absence of the SDK restriction, a particular retrieval cause, or that the actor ignored visible text. Original judgments remain unmodified.

No candidate repair, installed-skill update, production-source edit, commit or publication was performed. Remaining coverage and semantic disagreement are intentionally visible.

## Raw outputs appendix

### A. Activation

Not rerun; description is byte-identical. No historical trigger rate is relabeled as a current result.

### B. Cold reader

[Full independent answers](../../../../cold-reader.txt), without author context or other results.

### C. Executor artifacts and audited native trajectories

| Case | Exact task | Actual answer | Saved research record | Audited trace |
|---|---|---|---|---|
| C01 | [prompt](../../../../runs/C01/prompt.txt) | [answer](../../../../runs/C01/answer.txt) | [record](../../../../runs/C01/workspace/docs/loom/research/2026-11-09-small-pr-two-maintainers.md) | [trace](../../../../audit-packet/traces/C01/trajectory.jsonl) |
| C02 | [prompt](../../../../runs/C02/prompt.txt) | [answer](../../../../runs/C02/answer.txt) | [record](../../../../runs/C02/workspace/docs/loom/research/2026-11-09-git-branch-delete-guarantees.md) | [trace](../../../../audit-packet/traces/C02/trajectory.jsonl) |
| C03 | [prompt](../../../../runs/C03/prompt.txt) | [answer](../../../../runs/C03/answer.txt) | [record](../../../../runs/C03/workspace/docs/loom/research/2026-11-09-package-name-major-version.md) | [trace](../../../../audit-packet/traces/C03/trajectory.jsonl) |
| C04 | [prompt](../../../../runs/C04/prompt.txt) | [answer](../../../../runs/C04/answer.txt) | [record](../../../../runs/C04/workspace/docs/loom/research/2026-11-09-rime-save-options.md) | [trace](../../../../audit-packet/traces/C04/trajectory.jsonl) |
| C05 | [prompt](../../../../runs/C05/prompt.txt) | [answer](../../../../runs/C05/answer.txt) | [record](../../../../runs/C05/workspace/docs/loom/research/2026-11-09-toss-readability-cohesion.md) | [trace](../../../../audit-packet/traces/C05/trajectory.jsonl) |
| C06 | [prompt](../../../../runs/C06/prompt.txt) | [answer](../../../../runs/C06/answer.txt) | [record](../../../../runs/C06/workspace/docs/loom/research/2026-11-09-ydb-online-read-only.md) | [trace](../../../../audit-packet/traces/C06/trajectory.jsonl) |

### D. Blind judgments

[A01 verbatim](../../../../audits/A01.json) · [A02 verbatim](../../../../audits/A02.json) · [coarse comparison](../../../../comparison.json). Same requested model/effort and fixed rubric; neither saw the other judgment, cold-reader findings or the author's interpretation.

### E. Integrity and provenance

[Native export/model provenance](../../../../trace-export-summary.json) · [prospective hashes](../../../../freeze.json) · [audited packet hashes](../../../../audit-packet-freeze.json) · [one-use exporter](../../../../collect_traces.py) · [final verification](../../../../verification.json). The exporter is experimental tooling outside the plugin, not a maintained dependency. The [preliminary report](../../../../preliminary-report.md) is retained as an explicitly superseded in-progress snapshot.
