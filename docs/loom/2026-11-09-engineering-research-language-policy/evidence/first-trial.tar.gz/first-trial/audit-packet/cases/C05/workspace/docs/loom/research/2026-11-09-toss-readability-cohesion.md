---
title: "Toss 原則中的可讀性與內聚性取捨"
type: loom-research
status: concluded
created: 2026-11-09
updated: 2026-11-09
tags:
  - loom/research
---

# Toss 原則中的可讀性與內聚性取捨

## Question and scope

採用 Frontend Fundamentals 時，如何處理「容易理解」與「必須一起修改的程式能一起改」之間的衝突？本次研究範圍是官方韓文指引及其教學案例，查閱日為 2026-11-09；沒有使用者專案程式碼，也沒有授權實作或改變團隊規範。

## Method and rationale

直接閱讀維護者網站的原始說明，並作輕量條件比較：漏改的正確性風險、閱讀所需上下文、共同修改範圍，以及未來需求分歧。入口已提供足以直接定位的韓文原始材料，因此沿官方連結調查，不額外發出英日搜尋湊語言數。不同語言版同屬一套文件，不作獨立佐證。案例是官方教學程式的靜態閱讀，並非產品實測或產業普遍性的證據。停止條件是能提出條件式取捨，並找到挑戰「抽象化必然難讀」的反例。

## Findings

1. **原文主張：共同目標是長期容易修改。** 可讀性意指讀者容易理解行為；內聚性意指應一起修改的地方能一起修改；耦合度則關乎修改的影響範圍。四個品質面向難以同時最大化。[四項準則](https://frontend-fundamentals.com/code-quality/code/)
2. **原文的優先條件：漏改會導致錯誤時，優先內聚性；風險不高時，優先可讀性並容許重複。** 這不是「所有重複都要抽出」或「可讀性永遠優先」的規則；文件沒有給出量化的高風險門檻。[四項準則，內聚性與多角度章節](https://frontend-fundamentals.com/code-quality/code/)
3. **反例：不一定真有衝突。** FriendInvitation 將邀請按鈕與確認、送出邏輯封裝成 InviteButton，既降低頁面需要理解的上下文，也拉近一起修改的 UI 與事件處理。這支持先找局部封裝方式，再決定犧牲哪一項。[抽象化實作細節](https://frontend-fundamentals.com/code-quality/code/examples/login-start-page.html)

## Evidence

以下皆為同一官方文件體系的不同案例，沒有當作多份獨立經驗報告。

| 已讀案例與來源 | 原文情境、建議 | 適用邊界與研究判讀 |
|---|---|---|
| [動畫延遲常數](https://frontend-fundamentals.com/code-quality/code/examples/magic-number-cohesion.html) | 點讚後等待 300 毫秒再重新讀取；若數值為動畫時長，動畫變更而延遲漏改可能使流程失序。原文改為 ANIMATION_DELAY_MS。 | 名稱揭露依賴，但展示片段沒有動畫端共用該常數的程式；不能宣稱僅重新命名就已保證同步。實際採用還要確認兩端依賴同一時長來源。 |
| [表單的內聚單位](https://frontend-fundamentals.com/code-quality/code/examples/form-fields.html) | 欄位獨立驗證或跨表單重用時，採欄位單位；密切相關的業務流程、步驟相依、密碼確認或總額等互相影響時，採表單整體。已讀欄位 validate 與整體 zod schema 的展示程式。 | 依「需求一起改的單位」選邊界，並非把所有表單邏輯集中就更好。整體管理也可能降低重用性。 |
| [維護通知底部面板 Hook](https://frontend-fundamentals.com/code-quality/code/examples/use-bottom-sheet.html) | 共用 Hook 同時記錄日誌、開啟面板並關閉頁面；各頁可能有不同日誌、關頁要求與外觀。原文容許重複；只有行為與外觀相同、未來也預期一致才值得共用。 | 外觀相似不等於同一需求。共用會放大修改與回歸測試範圍；這是耦合成本，而非純粹的閱讀成本。 |
| [簡單權限的閱讀跳轉](https://frontend-fundamentals.com/code-quality/code/examples/user-policy.html) | Page 經 getPolicyByRole 再查 POLICY_SET，理解簡單規則需反覆跳轉。原文展示直接分支或元件內權限物件；也說複雜權限仍可能適合抽象。 | 支持簡單、局部規則就地呈現；不能外推為應移除所有集中權限規則，更不代表前端按鈕控制能替代後端授權。 |
| [同改檔案置於同目錄](https://frontend-fundamentals.com/code-quality/code/examples/code-directory.html) | 按 domain 放置相關檔案，使依賴與刪除範圍容易辨識，而不只按 hooks、utils 等類型散放。 | 能增加修改線索，不代表目錄本身會自動禁止跨域引用；本次沒有驗證工具強制邊界。 |

來源身分：官方[開始頁](https://frontend-fundamentals.com/code-quality/code/start.html)列出作者，準則頁的編輯連結指向 toss/frontend-fundamentals 的 fundamentals/code-quality/code/index.md。該 GitHub 編輯頁在本次工具讀取時被 robots.txt 阻擋，未取得固定 commit 或歷史作者驗證。本報告依據可讀取的官方網站現行文件，不聲稱完成儲存庫實作調查。

## Decision impact

建議採用「變更情境優先」的評審方式，而非為兩種原則排永久順位。以下是本次從官方案例整理的操作建議，並非原文逐字規範：

1. 先說出下一種具體需求變更，以及哪些地方若沒有同改會出錯。已知必須一致的規則，優先共用最小規則來源或把相關程式放近。
2. 檢查能否用有意義的局部元件或相鄰檔案，同時減少上下文與漏改風險；InviteButton 是可行反例。
3. 若只是目前長得像、未來有各自需求，保留局部重複，避免為共用增加分支參數和全站測試負擔。
4. 若規則簡單且局部，就地表達；若規則複雜且確實跨處一致，再承擔抽象層與閱讀跳轉成本。

會改變建議的證據包括：曾因漏改造成錯誤、需求確認必須一致、實際變更經常同時涉及同一群檔案，或共用元件已累積許多頁面專屬分支。這些都是待團隊個案提供的證據，這次未實際取得。

## Limitations and open questions

- 沒有本地專案、變更歷史或讀者觀察，無法替團隊某一具體元件作最終選擇；也未實測重構後的可讀性、錯誤率或效能。
- 官方案例是指引與示意碼，不是受控實驗或產業共識。抽象化不必然降低可讀性，原文案例本身就能同時改善兩者。
- 未讀翻譯版，不以其重複結論增加可信度；未聲稱掌握個別維護者未公開的意圖。網站沒有提供本次可讀的明確文件版號，日後重大更新須再驗。
- 已透過網頁工具讀取上述外部連結的實質內容；GitHub 編輯連結讀取失敗。紀錄內沒有本地 Markdown 證據連結，故無相對連結目標須解析。
