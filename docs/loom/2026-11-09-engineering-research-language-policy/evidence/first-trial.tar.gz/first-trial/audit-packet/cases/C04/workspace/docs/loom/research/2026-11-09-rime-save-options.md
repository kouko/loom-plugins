---
title: "Rime save_options 與按鍵切換的保存限制"
type: loom-research
status: concluded
created: 2026-11-09
updated: 2026-11-09
tags:
  - loom/research
---

# Rime save_options 與按鍵切換的保存限制

## Question and scope

實際問題：我們在評估 Rime 的選項狀態保存方案，需要釐清 save_options 與按鍵切換選項的適用限制。從上游 rime/home Wiki 線索出發，探索相關官方說明及維護討論；區分文件承諾、版本條件與未實測效果，不安裝 Rime。入口 https://github.com/rime/home/wiki 。

未提供目標前端、作業系統或已安裝版本。本次檢查公開文件、上游討論及原始碼，不改使用者設定、不安裝或執行 Rime。無已知 active change，故保存為獨立研究。

## Method and rationale

採文件、原始碼與版本紀錄對照：這是「哪些操作會走到保存路徑」的事實缺口，不需要評分模型或效能實驗。先從指定 Wiki 導航，再查上游 issue，追查實作的載入、按鍵執行、選單更新與初始化路徑。

探索查詢第一輪同時使用英、日、中：英文保留 API 名稱尋找功能請求，日文尋找操作限制，中文從第一輪加入，因 Rime Wiki 與相關上游討論主要使用中文。五條實際查詢列於 actions.json；不是以翻譯頁數作佐證。

先讀 1.13.1 作定位；發現 release/latest 指向 1.17.0 後，重新讀取 1.17.0 的關鍵路徑，以此作主要版本邊界。已核對 release commit 為 `33e78140250125871856cdc5b42ddc6a5fcd3cd4`。另看 master 作線索，不把未發行改動等同已安裝行為。

## Findings

1. **保存與切換是兩個不同動作。** `switcher/save_options` 是要記住的選項名稱集合，不是監聽所有按鍵變更的通用開關。1.17.0 中，方案選單將已列入集合的值寫至 user config 的 `var/option/<name>`；直接 `key_binder` 的 `toggle`、`set_option`、`unset_option` 則修改目前 Context（輸入工作階段的狀態物件），沒有同樣的保存呼叫。這是原始碼觀察，非本機實測。[E3][E4][E5]
2. **`reset` 會覆蓋恢復值。** 引擎建立時先恢復已保存選項，再初始化方案開關；初始化會套用非負的 reset 值，切換方案也會再初始化。因此若目標是延續上次選擇，不能同時依賴 `reset: 0/1` 強制初始化該開關。這不表示含 reset 的選項完全不能寫入，而是寫入後仍可能被覆蓋。[E5][E6]
3. **按鍵操作仍有條件。** 需要方案載入 `key_binder`、有效的 `when`/`accept`，且按鍵確實到達該處理器；`when: always` 只是引擎內的匹配條件，不能保證作業系統不攔截。1.17.0 支援以名稱或 `@n` 切換；多選群組的 toggle 會循環，set_option 選取指定成員。[E4][E6]
4. **中西文切換方式不可混為一談。** Wiki 對 `ascii_composer` 的 `inline_ascii` 說明是回車上屏後回中文；`commit_text` 與 `commit_code` 分別先送出候選文字或原始編碼。這些輸入處理策略不等於持久保存。1.17.0 的 switch_key 載入拒絕帶 modifier 的設定鍵名，不能直接把任意組合鍵當作同一功能。[E1][E7]
5. **維護討論有相同問題線索，但不是發行保證。** #1013 的提出者於 2025-05-16 指出 toggle 不受 save_options 保存，要求新增 toggle_option；讀取頁面仍顯示 Open，沒有維護者承諾或修復版本。其範例用 send_sequence 模擬 F4 後選第 2 項，並清除 reset；這只支持一個配置案例，不能保證其他選單排序、折疊或快捷鍵配置可直接套用。[E8]

## Evidence

- **E1 官方 Wiki 文件：** [CustomizationGuide](https://github.com/rime/home/wiki/CustomizationGuide)，頁面顯示 2026-10-11 編輯。實讀中西文切換策略、custom.yaml 補靪及重新部署說明。文件介紹操作方式，沒有在該頁找到 save_options 的完整保存契約，不能把策略描述擴張為跨視窗同步保證。
- **E2 Wiki 指向的作者文件：** [雪齋 Rime_description.md](https://github.com/LEOYoon-Tsaw/Rime_collections/blob/master/Rime_description.md)，實讀「開關」與 key_binder 節。此為 Wiki 推薦的外部作者文件，並非 rime/librime 發行規格；可作語法線索，其「切換窗口」描述不能取代前端驗證。該文件也把 select 描述成選候選字；本次版本原始碼的 key_binder/select 實際呼叫 select_schema，故以程式路徑界定此版本，未沿用該描述。
- **E3 上游原始碼，1.17.0：** [switch_translator.cc](https://github.com/rime/librime/blob/33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/gear/switch_translator.cc#L52)，讀取 `Switch::Apply`、`RadioGroup::SelectOption`、`LoadSwitches`。選單操作依 IsAutoSave 寫 var/option；缺 state label 的開關不產生同樣的可見選單項。
- **E4 上游原始碼，1.17.0：** [key_binder.cc](https://github.com/rime/librime/blob/33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/gear/key_binder.cc#L80)，讀取 toggle/set/unset、LoadBindings、條件判斷及 PerformKeyBinding。後者真正呼叫 action 或把 send_sequence 中的按鍵送回引擎；未走選單的 user-config 寫入。內部 C++ 函式名 toggle_option 不等於已支援同名 YAML 欄位，載入分支仍為 toggle。
- **E5 上游原始碼，1.17.0：** [switcher.cc](https://github.com/rime/librime/blob/33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/switcher.cc#L37)，實讀 RestoreSavedOptions、LoadSettings、IsAutoSave、OnSelect 與 SetActiveSchema。從 switcher/save_options 建集合，從 var/option 恢復值；選中選單命令後 Apply。SetActiveSchema 有 Save 呼叫。本次沒有繼續驗證所有磁碟落盤時機或異常關閉耐久性，不宣稱按下選項後已同步寫入磁碟。
- **E6 上游原始碼，1.17.0：** [engine.cc](https://github.com/rime/librime/blob/33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/engine.cc#L66)，實讀建構子、ProcessKey、OnOptionUpdate、ApplySchema 與 InitializeOptions（L356）。恢復順序先於 reset；OnOptionUpdate 更新組字並向前端發通知，沒有通用保存分支。另讀 [1.13.1 switches.cc](https://github.com/rime/librime/blob/1c23358157934bd6e6d6981f0c0164f05393b497/src/rime/switches.cc#L6)：未設定 reset 時以 -1 表示；1.17.0 同檔取回失敗，未宣稱已逐行核對其解析實作。
- **E7 官方文件與原始碼的版本邊界：** [1.17.0 release](https://github.com/rime/librime/releases/tag/1.17.0) 是本次 latest 重新導向的結果；[ascii_composer.cc](https://github.com/rime/librime/blob/33e78140250125871856cdc5b42ddc6a5fcd3cd4/src/rime/gear/ascii_composer.cc#L26) 實讀 load_bindings 與 ProcessKeyEvent，帶 modifier 的 switch_key 名稱會被拒絕，且有按鍵狀態與時間條件。未推定所有前端已包含此引擎版本。
- **E8 上游使用者問題報告：** [librime #1013](https://github.com/rime/librime/issues/1013)；[提出者範例](https://github.com/lumynou5/dotfiles/blob/junk/rime/memorize-ascii-mode/.config/ibus/rime/iridium_bpmf.custom.yaml)，實讀 reset 清除及 `{F4}{2}` 綁定。作者是問題提出者，頁面沒有足以確認其為維護者的標示；不把其「only」措辭視為已窮盡所有前端/API 的證明。
- **E9 上游維護討論線索：** [librime #631](https://github.com/rime/librime/issues/631)，2023-03-28，提出者描述 toggle ascii_mode 與 commit_code 的差異；Contributor shewer 留下按鍵事件範例，但沒有維護者採納承諾。另讀 [#1154](https://github.com/rime/librime/issues/1154) 的 2026-04-03 問題本文；搜尋結果含互相不同的組合鍵成功報告，但開啟頁面未提供那些完整留言，故不採為已驗證效果。
- **E10 官方版本紀錄：** [CHANGELOG](https://github.com/rime/librime/blob/master/CHANGELOG.md#1110-2024-03-29) 將重複載入保存選項的修正列於 1.11.0。對應 commit 頁面取回失敗，故僅記錄 release-note 說明，不自行推斷所有舊版的症狀；不能將 1.17.0 的恢復時機套到所有歷史版本。

## Decision impact

若需求是「選單選定後，下次輸入工作階段能恢復」，可把 save_options 加上避免 reset 覆蓋作為候選設計；需核對實際開關名稱與前端版本。若需求是「任何快捷鍵一切換都要保存，並即時同步所有視窗」，單靠 save_options + toggle 的證據不足，且 1.17.0 的直接切換路徑不提供該寫入。

send_sequence 模擬選單可列為待驗證替代，不作穩定通用解法。選單位置、折疊、既有按鍵綁定與 OS 攔截都可能使同一序列效果不同。跨視窗即時同步、程式重啟、系統重啟與正常落盤是不同驗證項目。

## Limitations and open questions

- 沒有安裝 Rime，沒有執行 Rime、編譯或測試；本報告全部屬文件、討論與原始碼觀察。
- 目標前端與引擎版本未提供；前端可能接收 option 通知後自行管理或保存狀態，本次不概括鼠鬚管、小狼毫、IBus、Fcitx 的完整行為。
- 命令列 Python urllib 對五個公開 URL 的嘗試均遇 DNS 錯誤；改用可用的 web 工具閱讀。部分 GitHub 留言、API、commit 與 raw 檔案取回失敗，未當作不存在或已讀證據。
- 需要實機驗證時，應在指定前端比較「選單／toggle」、「有／無 reset」、「同工作階段／新工作階段／重啟」並觀察 user.yaml；這是剩餘證據需求，本次未執行。
- 已在寫入後完整讀回本文件；證據實質內容以本次讀取的 tag raw 原始碼為準，commit 連結以 release 指向的 SHA 固定。另檢查五個 1.17.0 commit permalink：key_binder、engine、ascii_composer 可取回；switch_translator、switcher 的 GitHub blob 頁遇 cache miss，但對應 tag raw 已讀，未把 blob 取回失敗視為不存在。本文無本地 Markdown 證據連結；answer.txt 指向本研究的本地連結已解析確認存在，actions.json 已解析確認語法有效。
