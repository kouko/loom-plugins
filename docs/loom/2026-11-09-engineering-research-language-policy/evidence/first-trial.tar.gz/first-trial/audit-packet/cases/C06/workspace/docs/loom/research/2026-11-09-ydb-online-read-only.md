---
title: "YDB Online Read-Only 限制與替代方案核對"
type: loom-research
status: concluded
created: 2026-11-09
updated: 2026-11-09
tags:
  - loom/research
---

# YDB Online Read-Only 限制與替代方案核對

## 問題與條件

核對 YDB Online Read-Only 的文件限制與替代方案，區分文件支持和未驗證部分。不部署、不執行資料庫。沒有指定部署版本、SDK 或工作負載；本次適用範圍是查閱當日標示 v26.3 的官方文件，不能直接外推到既有安裝。

## 方法與理由

直接核對官方交易說明及其 SDK 說明，依是否純讀取、是否讀取欄式表、是否需要一致快照作條件比較。主要線索已是適用的俄文原始來源，因此直接閱讀俄文，不為語言數量另行搜尋英文或日文。文件已足以回答這項文件核對；不進行實作或效能驗證。

## 發現

以下均為文件支持，非執行觀察：

| 條件 | 官方說明與選項 |
| --- | --- |
| 新應用純讀取 | Online Read-Only 為 legacy，相容舊程式；建議 Snapshot Read-Only。 |
| 讀取欄式表 | Online Read-Only、Stale Read-Only 均不支援；文件指定 Serializable 或 Snapshot Read-Only。 |
| 多次讀取需一致狀態 | Snapshot Read-Only 使用一致快照，快照後提交不可見；建立快照可能增加延遲。 |
| 可接受較舊資料 | Stale Read-Only 可考慮，但沒有全交易一致快照、不支援互動交易；跨分片讀取改從 leader 取得快照，且仍不能讀欄式表。 |

## 證據與出處

- [俄文官方交易文件](https://ydb.tech/docs/ru/concepts/transactions)：頁面標示 v26.3；2026-11-09 讀取 Snapshot Read-Only、Stale Read-Only、Online Read-Only 及其欄式表限制段落。上述比較取自這些段落，屬文件契約。
- [俄文官方 SDK 交易模式說明](https://ydb.tech/docs/ru/recipes/ydb-sdk/tx-control)：標示 v26.3；讀取 Online Read-Only 範例，以及 Snapshot Read-Only 的 JDBC 與框架限制說明。範例存在不代表已執行、所有框架均支援或遷移可直接替換。
- 交易頁的 SDK 詳情連結實際解析成 `/docs/ru/concepts/ru/recipes/ydb-sdk/tx-control`，工具回傳 404；改開上述正確官方 URL 成功讀取。這是本次取得文件的觀察，並非資料庫錯誤。

## 決策影響

文件層面支持新純讀取優先考慮 Snapshot Read-Only；欄式表不可用 Online Read-Only 或 Stale Read-Only。Serializable 是文件提供的另一選項，表示成功交易結果等同某個依序執行順序。尚無應用條件可判定實際遷移方案，也沒有證據支持任何選項在使用者環境一定較快。

## 限制與未解問題

沒有檢查資料庫或 SDK 原始碼、沒有部署或執行查詢。錯誤是否實際出現、舊版本行為、SDK 版本支援、延遲與吞吐量、遷移相容性均未驗證。不能把 Stale 的互動交易限制無條件移植成 Online 的限制，也不能從 legacy 推論 Online 已移除。需確切部署版本、SDK 與查詢條件才能完成環境適用性判斷。
