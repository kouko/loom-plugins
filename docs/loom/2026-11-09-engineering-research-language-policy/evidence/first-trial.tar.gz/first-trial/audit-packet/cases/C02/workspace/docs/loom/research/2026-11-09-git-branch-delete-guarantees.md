---
title: "git branch 刪除選項的保護範圍"
type: loom-research
status: concluded
created: 2026-11-09
updated: 2026-11-09
tags:
  - loom/research
---

# git branch 刪除選項的保護範圍

## Question and scope

核對官方文件中 `-d` 與 `-D` 的差異，以及是否保證所有工作不會遺失。僅查文件，不執行 Git 命令或改動 Git 狀態。

## Method and rationale

採用官方文件查證。已提供直接相關的英文原始來源，無須增加其他語言搜尋；補讀 git-gc 文件，確認提交永久保留的限制。選項條件與保留限制有直接文件支持即停止，不做實驗。

## Findings

- 文件事實：`-d` 要求分支完全合併至設定的上游分支；未設定上游才以 `HEAD`（目前所在提交）為準，並非一律檢查 main。
- 文件事實：`-D` 等同 `--delete --force`，允許忽略合併狀態及是否指向有效提交的檢查。
- 文件事實：兩者刪除分支時，該分支若有 reflog（分支指向變動的紀錄）也會刪除。
- 推論：這不是所有工作永不遺失的保證；合併檢查不是未提交檔案或遠端的備份保證。強制刪除更可能移除獨有提交的分支入口。
- 文件加推論：刪除分支不表示提交當下必然消失，其他分支、標籤或 reflog 可能保有引用；但沒有引用可到達的提交可能被後續清理移除，不保證永久可恢復。

## Evidence

1. [Git 官方 git-branch 文件](https://git-scm.com/docs/git-branch)：2026-11-09 直接讀取；頁面標示手冊最後更新於 2.56.0。核對 DESCRIPTION 的刪除與 reflog 說明，以及 OPTIONS 的兩個刪除選項、強制選項、合併篩選說明。屬文件證據，未檢查實作。
2. [Git 官方 git-gc 文件](https://git-scm.com/docs/git-gc)：2026-11-09 直接讀取 DESCRIPTION、prune 選項、gc.pruneExpire 及 NOTES；核對不可到達物件的清理與保留引用。屬目前網站文件，未固定版本。

## Decision impact

可將小寫選項視為有合併條件的刪除，大寫選項視為略過該條件的強制刪除；兩者都不是完整資料保留承諾。本次不判定任何特定分支是否適合刪除。

## Limitations and open questions

未執行任何 Git 命令、刪除或清理；未檢查本機版本、設定、引用、未提交檔案或遠端保存情況。沒有實作驗證或復原實驗，無法判定特定提交能否找回。外部來源已開啟並讀取支持段落；沒有本機 Markdown 連結需要解析。
