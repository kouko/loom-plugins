"""One-use evidence export for this experiment's exact native agent paths."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
PARENT = "01a1b508-8bbc-7c91-97d5-4a738e7c6d2a"
NAMES = [f"lang_exec_c{i:02}" for i in range(1, 7)] + ["lang_cold_reader", "lang_audit_01", "lang_audit_02"]
SOURCES = [Path("/Users/kouko/.codex/sessions/2026/11/08"), Path("/Users/kouko/.codex/sessions/2026/11/09")]
summary = []
for directory in SOURCES:
    for source in directory.glob("*.jsonl"):
        with source.open() as stream:
            first = json.loads(next(stream))
            origin = first.get("payload", {}).get("source", {})
            spawn = origin.get("subagent", {}).get("thread_spawn", {}) if isinstance(origin, dict) else {}
            path = spawn.get("agent_path", "")
            name = path.removeprefix("/root/")
            if spawn.get("parent_thread_id") != PARENT or name not in NAMES:
                continue
            kept, blinded, calls, models, efforts, redactions = [], [], {}, set(), set(), []
            for raw in stream:
                item = json.loads(raw)
                payload = item.get("payload", {})
                kind = payload.get("type", "")
                if item.get("type") == "turn_context":
                    models.add(payload.get("model"))
                    efforts.add(payload.get("effort", payload.get("reasoning_effort")))
                if item.get("type") != "response_item":
                    continue
                if kind in ("custom_tool_call", "function_call"):
                    clean = {k: payload[k] for k in ("type", "name", "call_id", "input", "arguments") if k in payload}
                    code = str(clean.get("input", clean.get("arguments", "")))
                    calls[clean["call_id"]] = code
                elif kind in ("custom_tool_call_output", "function_call_output"):
                    clean = {k: payload[k] for k in ("type", "call_id", "output") if k in payload}
                    code = calls.get(clean["call_id"], "")
                    body = json.dumps(clean.get("output"), ensure_ascii=False)
                    if "web__run" in code:
                        raw_output = clean.get("output", [])
                        parts = raw_output if isinstance(raw_output, list) else [{"text": str(raw_output)}]
                        returned_text = "\n".join(x.get("text", "") for x in parts if isinstance(x, dict))
                        # Preserve actual calls plus source identities, not full copyrighted pages.
                        clean["output"] = {
                            "source_text_omitted": True,
                            "reason": "External page/search body is not republished; audit cited claims at original URLs.",
                            "original_output_sha256": hashlib.sha256(body.encode()).hexdigest(),
                            "original_output_bytes": len(body.encode()),
                            "urls": sorted(set(re.findall(r"https?://[^\s<>\"\\]+", body))),
                            "reference_ids": sorted(set(re.findall(r"turn\d+(?:search|view|fetch|academia)\d+", body))),
                            "access_error_observed": bool(re.search(r"Internal Error|403 Forbidden|404 Not Found|not accessible via this tool", body)),
                            "find_no_match_observations": sorted(set(line.strip()[:300] for line in returned_text.splitlines()
                                                                     if line.strip().startswith("No matching text found for"))),
                        }
                elif kind == "agent_message":
                    clean = {k: payload[k] for k in ("type", "author", "recipient", "content") if k in payload}
                elif kind == "message" and payload.get("role") == "user":
                    clean = {k: payload[k] for k in ("type", "role", "content") if k in payload}
                elif kind == "message" and payload.get("role") == "assistant" and (payload.get("channel") == "final" or payload.get("phase") == "final_answer"):
                    clean = {k: payload[k] for k in ("type", "role", "channel", "phase", "content") if k in payload}
                else:
                    continue
                record = {"timestamp": item.get("timestamp"), "payload": clean}
                kept.append(record)
                blind = json.loads(json.dumps(record))
                if kind in ("custom_tool_call_output", "function_call_output"):
                    code = calls.get(clean["call_id"], "")
                    if "/candidate/engineering-research/" in code and "web__run" not in code:
                        body = json.dumps(clean.get("output"), ensure_ascii=False)
                        masked, matched = body, []
                        for resource in (ROOT / "candidate/engineering-research").rglob("*.md"):
                            content = json.dumps(resource.read_text(), ensure_ascii=False)[1:-1]
                            if content and content in masked:
                                marker = json.dumps("[Skill text withheld: " + resource.name + "]", ensure_ascii=False)[1:-1]
                                masked = masked.replace(content, marker)
                                matched.append(resource.name)
                        if matched:
                            # Leave co-returned task/fixture/artifact data unchanged.
                            blind["payload"]["output"] = json.loads(masked)
                        else:
                            blind["payload"]["output"] = {
                                "skill_body_withheld": True,
                                "original_output_sha256": hashlib.sha256(body.encode()).hexdigest(),
                                "original_output_bytes": len(body.encode()),
                                "truncation_marker_present": "truncated" in body.lower(),
                                "note": "No exact whole-source match; output withheld, not proof of a full read.",
                            }
                        redactions.append({"call_id": clean["call_id"], "exact_source_matches": matched,
                                           "fallback_whole_result": not bool(matched)})
                blinded.append(blind)
        target = ROOT / "traces" / name
        target.mkdir(parents=True, exist_ok=True)
        for filename, records in (("trajectory.jsonl", kept), ("audit-trajectory.jsonl", blinded)):
            (target / filename).write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records))
        info = {"agent_path": path, "thread_id": first["payload"]["id"], "source_file": source.name,
                "host_reported_models": sorted(m for m in models if m),
                "host_reported_efforts": sorted(e for e in efforts if e), "retained_records": len(kept),
                "retained_hidden_reasoning": 0, "skill_read_outputs_masked_for_audit": redactions,
                "web_source_bodies_republished": False, "scope": "Exact new child only; no parent history or other sessions."}
        (target / "provenance.json").write_text(json.dumps(info, indent=2) + "\n")
        summary.append(info)
(ROOT / "trace-export-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"exported_agents": len(summary), "retained_hidden_reasoning": 0}))
