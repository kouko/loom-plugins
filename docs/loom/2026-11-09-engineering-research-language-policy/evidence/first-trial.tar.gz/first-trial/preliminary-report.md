# Dogfood report — engineering-research language-policy trial 1

## Metadata

| Field | Value |
|---|---|
| Status | In progress; no overall pass verdict |
| Skill | Frozen raw candidate under candidate/engineering-research |
| Baseline | loom-code 3.60.0 at 11b962b7f2c83f397c52d0753fd890ffec06e74b; byte reference only, not an executed control |
| Date | 2026-11-09 |
| Requested native model | gpt-6.1-sol, medium; host-reported model retained separately, not provider attestation |
| Scope | Six fresh explicit-invocation workflow cases, two independent auditors and one cold reader |
| Activation | Not rerun; description unchanged; no current activation result or dogfood-pass |
| Isolation | Fresh no-parent-history actors; native host defaults are not an empty catalog or hard filesystem sandbox |

## Severity summary

Pending independent audits. Case observations below are not quality verdicts.

## Findings

### Provisional F01 — SDK-specific condition missing from C06

A01 reports Medium / Output-quality: C06 omits the official SDK page limitation for Online Read-Only JDBC interactive transactions. The case records a warning not to transfer the Stale limit to Online, rather than the scoped JDBC condition. Source: audits/A01.json, F01, citing the C06 research record and the official SDK page. Consequence: a relevant condition remains unstated. Suggested action is a case-report correction with explicit SDK scope, not more languages or a new skill rule. This is an advisory domain finding, not a language-policy failure; original source-return coverage remains uncertain because public source bodies are not in the audit packet. A02 is still independent and pending.

Cold-reader observations are retained in cold-reader.txt: standalone save-root, ordinary-review entry boundary and optional cleanup integration remain ambiguous to that reader. They are unchanged baseline text, not established regressions from the added language paragraph. The reader found the actual search-language procedure actionable. No automatic repairs were made.

## Observed case progress

| Case | Actual observation so far | Limit |
|---|---|---|
| C01 | Actual first web call contains separate English and Japanese queries in one batch; external sources read; record and answer produced | No comparative quality or activation claim |
| C02 | Direct official-document opens; zero search_query calls; record and answer produced | A rejected text-write command was replaced with apply_patch; no Git deletion or state change occurred |
| C03 | Genuine local manifest answered; record and local evidence link read back | Actual native trace has zero web calls; independent quality judgments remain pending |

C04 completed: its first actual web batch opens the upstream Wiki and issues English, Japanese and Chinese queries; no gratuitous Korean query is observed in that batch. It follows relevant implementation at a release and retains untested runtime limits. This is a trajectory observation, not an independent quality verdict.

## Raw outputs appendix

### A. Activation
Not rerun. This is a bounded language-workflow test, not a full activation+workflow pass.

### B. Cold reader
Pending fresh independent reading.

### C. Executor artifacts
Actual per-case answer.txt, actions.json and Markdown records live under runs/C01 through runs/C06. Final report will link the completed artifacts and hashes.

### D. Actual executor trajectories
Filtered native tool-call/result exports are under traces/lang_exec_c01 through traces/lang_exec_c06. Only these exact new child paths are exported; hidden reasoning and parent history are omitted. Public web source bodies are not republished: exact calls, result URLs/IDs, content hashes and access-error observations are retained. Auditors verify factual claims at original sources. Successful skill-text read outputs are masked only in auditor copies; raw invocation, timestamps and truncation observations remain visible.

### E. Independent judgments
Pending two fresh independent model-pinned auditors. Findings are advisory, not a claim of causal benefit or general reliability.
